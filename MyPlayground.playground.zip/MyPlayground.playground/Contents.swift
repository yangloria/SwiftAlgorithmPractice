import UIKit

var str = "Hello, playground"

class solution {

    public func solution(_ x: Int, _ y: Int, _ d: Int) -> Int {

        let doubleX = Double(x)
        let doubleY = Double(y)
        let doubleD = Double(d)
        
        return Int(ceil((doubleY - doubleX) / doubleD))
    }
}
